"""Design-system audit for the nusasec-website package.

Counterpart of nusasec-core's scripts/design_system_audit.py, adjusted for
this repo's folder layout (design/index.html, shared/design-system/tokens.css)
after the core/website split. Run this from the website repo; the core repo's
copy of this script self-skips when those paths aren't present there.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
required = [
    ROOT / "docs/design-system/NUSASEC_DESIGN_SYSTEM_V1.md",
    ROOT / "shared/design-system/tokens.css",
    ROOT / "design/index.html",
]
for path in required:
    assert path.exists(), f"missing: {path}"
html = (ROOT / "design/index.html").read_text(encoding="utf-8")
css = (ROOT / "shared/design-system/tokens.css").read_text(encoding="utf-8")
doc = (ROOT / "docs/design-system/NUSASEC_DESIGN_SYSTEM_V1.md").read_text(encoding="utf-8")
for needle in ["Customer Control Plane", "Context selector", "Notifications", "Maintenance", "RTL", "reduced-motion"]:
    assert needle.lower() in (html + doc).lower(), needle
for token in ["--ns-bg", "--ns-surface", "--ns-brand", "--ns-critical", "--ns-radius-md", "--ns-space-4", "--ns-sidebar"]:
    assert token in css, token
assert "/shared/design-system/tokens.css" in html, "design preview must link the shared tokens stylesheet"
print("DESIGN_SYSTEM_AUDIT: PASS")
