// nusasec-website static + reverse-proxy server
//
// Serves the public site, customer console, internal console, login page,
// design-system preview and shared assets at exactly the same URL prefixes
// the old NusaSec monolith used to mount them at (/site, /app, /internal,
// /login, /design, /shared), and reverse-proxies everything else
// (/api/*, /health, /docs, /openapi.json, /redoc) to the separately deployed
// Core API (`nusasec-core`).
//
// Keeping the same origin for both the website and the API in production is
// the recommended setup: it lets the session cookie stay SameSite=Lax and
// avoids needing CORS at all. Set CORE_API_BASE_URL to point at wherever the
// nusasec-core service is running.
//
// Usage:
//   cd server && npm install && CORE_API_BASE_URL=http://localhost:8000 npm start

const path = require('path');
const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

const ROOT = path.join(__dirname, '..');
const CORE_API_BASE_URL = process.env.CORE_API_BASE_URL || 'http://localhost:8000';
const PORT = process.env.PORT || 3000;

const app = express();

// Proxy API + backend-served docs to the Core service first, before the
// static handlers below, so /api/... never gets shadowed by a static 404.
app.use(
  ['/api', '/health', '/docs', '/redoc', '/openapi.json'],
  createProxyMiddleware({
    target: CORE_API_BASE_URL,
    changeOrigin: true,
    xfwd: true,
  })
);

// Static consoles/pages, at the same prefixes the previous FastAPI monolith
// used (app.mount("/app", ...), etc.) so none of the existing absolute
// hrefs/fetch() calls inside the HTML/JS need to change.
app.use('/site', express.static(path.join(ROOT, 'site'), { extensions: ['html'] }));
app.use('/app', express.static(path.join(ROOT, 'web'), { extensions: ['html'] }));
app.use('/internal', express.static(path.join(ROOT, 'internal'), { extensions: ['html'] }));
app.use('/login', express.static(path.join(ROOT, 'login'), { extensions: ['html'] }));
app.use('/design', express.static(path.join(ROOT, 'design'), { extensions: ['html'] }));
app.use('/shared', express.static(path.join(ROOT, 'shared')));

// Public marketing homepage.
app.get('/', (_req, res) => res.sendFile(path.join(ROOT, 'site', 'index.html')));

app.listen(PORT, () => {
  console.log(`nusasec-website listening on :${PORT}`);
  console.log(`proxying /api, /health, /docs, /redoc, /openapi.json -> ${CORE_API_BASE_URL}`);
});
