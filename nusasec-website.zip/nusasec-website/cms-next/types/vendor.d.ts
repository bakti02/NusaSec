declare namespace React { type ReactNode = unknown; }
declare module 'react' { export function useState<T>(initial:T): [T,(v:T)=>void]; }
declare module 'react/jsx-runtime' { export const jsx: any; export const jsxs: any; export const Fragment: any; }
declare module 'next' {}
declare module '@tiptap/react' { export const useEditor: any; export const EditorContent: any; }
declare module '@tiptap/starter-kit' { const x:any; export default x; }
declare module '@tiptap/extension-placeholder' { const x:any; export default x; }
declare module '@tiptap/extension-link' { const x:any; export default x; }
