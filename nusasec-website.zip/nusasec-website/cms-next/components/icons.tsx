export function Icon({ name }: { name: string }) {
  const paths: Record<string, string> = {
    grid: "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z",
    file: "M7 3h7l4 4v14H7zM14 3v5h5",
    globe: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3c3 3.4 3 14.6 0 18M12 3c-3 3.4-3 14.6 0 18",
    image: "M4 5h16v14H4zM7 15l3-3 2 2 2-3 3 4M8 9a1.5 1.5 0 1 0 0 .01",
    settings: "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8zM3.5 13.5l-1-1 1-3 1.4-.3.8-1.4-.6-1.3 2.2-2.2 1.3.6 1.4-.8.3-1.4 3-1 1 1 .3 1.4 1.4.8 1.3-.6 2.2 2.2-.6 1.3.8 1.4 1.4.3 1 3-1 1-1.4.3-.8 1.4.6 1.3-2.2 2.2-1.3-.6-1.4.8-.3 1.4-3 1-1-1-.3-1.4-1.4-.8-1.3.6-2.2-2.2.6-1.3-.8-1.4-1.4-.3z",
    search: "M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM20 20l-4.1-4.1",
    chevron: "M7 10l5 5 5-5",
    plus: "M12 5v14M5 12h14",
    eye: "M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z",
    more: "M5 12h.01M12 12h.01M19 12h.01",
    arrow: "M5 12h14M13 6l6 6-6 6",
    check: "M5 12l4 4L19 6",
    close: "M6 6l12 12M18 6L6 18",
    code: "M8 8l-4 4 4 4M16 8l4 4-4 4M13 5l-2 14",
    layers: "M12 3l8 4-8 4-8-4 8-4zM4 12l8 4 8-4M4 16l8 4 8-4",
    clock: "M12 7v5l3 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z",
    spark: "M12 3l1.5 5.5L19 10l-5.5 1.5L12 17l-1.5-5.5L5 10l5.5-1.5L12 3z",
  };
  return <svg viewBox="0 0 24 24" aria-hidden="true" className="icon"><path d={paths[name] ?? paths.spark} fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}
