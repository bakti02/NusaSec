"use client";

import { useState } from "react";
import { Icon } from "./icons";
import { RichEditor } from "./rich-editor";
import { page } from "../lib/content";

const locales = ["English", "Bahasa Indonesia", "简体中文", "繁體中文", "العربية", "日本語", "한국어", "Deutsch", "Nederlands", "Русский", "Español", "हिन्दी", "Français", "Português (Brasil)", "Italiano", "Türkçe"];

export function CmsWorkspace() {
  const [active, setActive] = useState("content");
  const [locale, setLocale] = useState("English");
  const [preview, setPreview] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [saved, setSaved] = useState(true);

  return <div className="cms-app">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark">N</div><div><strong>NUSASEC</strong><span>Content & Experience</span></div></div>
      <nav className="nav" aria-label="CMS navigation">
        <p className="nav-label">Workspace</p>
        {[['overview','Overview','grid'],['content','Content','file'],['media','Media library','image'],['navigation','Navigation','layers'],['releases','Releases','clock']].map(([id,label,icon]) => <button key={id} onClick={() => setActive(id)} className={`nav-link ${active===id?'active':''}`}><Icon name={icon}/><span>{label}</span></button>)}
        <p className="nav-label">Governance</p>
        {[['localization','Localization','globe'],['settings','Settings','settings']].map(([id,label,icon]) => <button key={id} onClick={() => setActive(id)} className={`nav-link ${active===id?'active':''}`}><Icon name={icon}/><span>{label}</span></button>)}
      </nav>
      <div className="sidebar-footer"><div className="tiny-status"><span className="dot"></span> Production-ready workflow</div><div className="avatar">AS</div></div>
    </aside>

    <main className="main">
      <header className="topbar">
        <button className="context-button"><span className="context-kicker">Project</span><strong>NusaSec Global</strong><Icon name="chevron"/></button>
        <div className="top-actions">
          <button className="search-button" onClick={() => setCommandOpen(true)}><Icon name="search"/><span>Search content</span><kbd>⌘ K</kbd></button>
          <button className="icon-button" aria-label="Preview"><Icon name="eye"/></button>
          <button className="avatar avatar-small">AS</button>
        </div>
      </header>

      <div className="pagebar">
        <div><div className="breadcrumbs">Content / Product / Platform</div><h1>{page.title}</h1><div className="subtle">{page.slug} · Last saved {page.updatedAt.replace('T',' ').slice(0,16)}</div></div>
        <div className="page-actions"><span className={`save-state ${saved?'':'dirty'}`}><span className="dot"></span>{saved?'Saved':'Unsaved changes'}</span><button className="ghost-button" onClick={() => setPreview(true)}>Preview</button><button className="primary-button" onClick={() => { setSaved(true); }}>Publish</button></div>
      </div>

      <div className="locale-row">
        <div className="locale-select"><Icon name="globe"/><select value={locale} onChange={e=>setLocale(e.target.value)} aria-label="Content locale">{locales.map(l=><option key={l}>{l}</option>)}</select><Icon name="chevron"/></div>
        <div className="workflow"><span className="workflow-step done">Draft</span><span className="workflow-line"></span><span className="workflow-step current">Review</span><span className="workflow-line"></span><span className="workflow-step">Publish</span></div>
      </div>

      <section className="editor-layout">
        <div className="canvas-panel">
          <div className="canvas-head"><div><span className="eyebrow">Structured page</span><h2>Page composition</h2></div><button className="icon-button"><Icon name="more"/></button></div>
          <div className="block-stack">
            <div className="block selected"><div className="block-label">Hero</div><div className="block-body hero-block"><div><span className="eyebrow">Platform</span><h3>See the security story behind every cloud asset.</h3><p>Bring cloud, identity, risk, compliance and evidence into one operating view.</p><button className="preview-cta">Explore platform <Icon name="arrow"/></button></div><div className="hero-orb"><div className="orb-ring"></div><div className="orb-core">N</div></div></div></div>
            <div className="block"><div className="block-label">Metrics</div><div className="metric-row">{page.blocks[1].type==='metrics' && page.blocks[1].items.map(x=><div className="metric" key={x.label}><span>{x.label}</span><strong>{x.value}</strong><em>+8.2%</em></div>)}</div></div>
            <div className="block"><div className="block-label">Feature grid</div><div className="feature-grid">{page.blocks[2].type==='feature-grid' && page.blocks[2].items.map((x,i)=><div className="feature-card" key={x}><span className="feature-number">0{i+1}</span><strong>{x}</strong><span className="feature-link">Edit block <Icon name="arrow"/></span></div>)}</div></div>
            <div className="block"><div className="block-label">Callout</div><div className="callout success"><div className="callout-icon"><Icon name="check"/></div><div><strong>Ready for enterprise</strong><p>Content is localized, reviewed and ready for a staged publish.</p></div></div></div>
            <button className="add-block"><Icon name="plus"/> Add content block</button>
          </div>
        </div>

        <aside className="inspector">
          <div className="inspector-head"><div><span className="eyebrow">Inspector</span><h2>Hero block</h2></div><button className="icon-button"><Icon name="close"/></button></div>
          <div className="field-group"><label>Block label</label><input defaultValue="Platform hero" onChange={()=>setSaved(false)}/></div>
          <div className="field-group"><label>Headline</label><textarea defaultValue="See the security story behind every cloud asset." onChange={()=>setSaved(false)} /></div>
          <div className="field-group"><label>CTA label</label><input defaultValue="Explore platform" onChange={()=>setSaved(false)}/></div>
          <div className="field-group"><label>Destination</label><div className="input-with-prefix"><span>/</span><input defaultValue="platform"/></div></div>
          <div className="inspector-section"><span className="eyebrow">Visibility</span><div className="toggle-row"><div><strong>Show in navigation</strong><span>Visible in public site menu</span></div><button className="toggle on" aria-label="Show in navigation"><span></span></button></div></div>
          <div className="inspector-section"><span className="eyebrow">SEO</span><div className="seo-score"><span>Metadata readiness</span><strong>92</strong></div><div className="mini-progress"><span style={{width:'92%'}}></span></div></div>
          <div className="inspector-section"><span className="eyebrow">Translation</span><div className="translation-row"><span>English</span><strong>Source</strong></div><div className="translation-row"><span>Bahasa Indonesia</span><span className="status-pill">Needs review</span></div></div>
        </aside>
      </section>

      {active==='content' && <div className="editor-note"><Icon name="spark"/> Structured blocks are reusable across the public site, release center, regulatory center and notifications.</div>}
      {active==='content' && <div className="rich-editor-section"><div><span className="eyebrow">Rich text</span><h2>Editorial copy</h2></div><RichEditor/></div>}

      {commandOpen && <div className="overlay" role="dialog" aria-modal="true"><div className="command"><div className="command-input"><Icon name="search"/><input autoFocus placeholder="Search pages, releases, media, languages…" /><kbd>ESC</kbd></div><div className="command-list"><button>Open Cloud Security Platform</button><button>Go to Release Center</button><button>Review translations</button><button>Open media library</button></div></div><button className="overlay-close" onClick={()=>setCommandOpen(false)}>Close</button></div>}
      {preview && <div className="overlay preview-overlay"><div className="preview-frame"><div className="preview-top"><div><span className="eyebrow">Live preview</span><strong>{locale}</strong></div><button className="icon-button" onClick={()=>setPreview(false)}><Icon name="close"/></button></div><div className="preview-site"><div className="preview-nav"><strong>NUSASEC</strong><div>Platform</div><div>Security</div><div>Compliance</div><div>Resources</div><button>Talk to us</button></div><div className="preview-hero"><span className="eyebrow">Cloud Security Platform</span><h3>See the security story behind every cloud asset.</h3><p>Bring cloud, identity, risk, compliance and evidence into one operating view.</p><button>Explore platform <Icon name="arrow"/></button></div><div className="preview-stat-row"><div><strong>94%</strong><span>Control coverage</span></div><div><strong>3</strong><span>Critical findings</span></div><div><strong>7</strong><span>Regulatory impacts</span></div></div></div></div></div>}
    </main>
  </div>;
}
