"use client";

import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Placeholder from "@tiptap/extension-placeholder";
import Link from "@tiptap/extension-link";

export function RichEditor() {
  const editor = useEditor({
    extensions: [StarterKit, Placeholder.configure({ placeholder: "Write the body copy…" }), Link.configure({ openOnClick: false })],
    content: `<h2>Cloud Security Platform</h2><p>Bring cloud, identity, risk, compliance and evidence into one operating view.</p>`,
    immediatelyRender: false,
  });

  if (!editor) return <div className="editor-skeleton">Loading editor…</div>;

  return <div className="editor-shell">
    <div className="editor-toolbar" role="toolbar" aria-label="Formatting">
      {[
        ["bold", "Bold"], ["italic", "Italic"], ["bulletList", "Bullet list"], ["orderedList", "Numbered list"], ["undo", "Undo"], ["redo", "Redo"]
      ].map(([name, label]) => <button key={name} className="tool-button" type="button" aria-label={label} onClick={() => {
        if (name === "bold") editor.chain().focus().toggleBold().run();
        if (name === "italic") editor.chain().focus().toggleItalic().run();
        if (name === "bulletList") editor.chain().focus().toggleBulletList().run();
        if (name === "orderedList") editor.chain().focus().toggleOrderedList().run();
        if (name === "undo") editor.chain().focus().undo();
        if (name === "redo") editor.chain().focus().redo();
      }}>{label}</button>)}
    </div>
    <EditorContent editor={editor} className="editor-content" />
  </div>;
}
