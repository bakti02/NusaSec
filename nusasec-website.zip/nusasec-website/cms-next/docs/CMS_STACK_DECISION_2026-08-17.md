# NusaSec CMS Stack Decision — 2026-08-17

## Decision

Use Next.js 16.2.11 + React 19.2.7 + TypeScript for the CMS/experience frontend, Tiptap for structured rich text, and Radix primitives as the accessibility/interaction foundation. Keep the existing Python/FastAPI backend and PostgreSQL system of record.

## Why

- Next.js 16.2.11 is in Active LTS as of July 2026.
- React 19.2 is the current latest React line and adds Activity, performance tracks, and partial pre-rendering capabilities.
- Radix provides accessible, unstyled primitives with focus management, keyboard navigation and RTL support.
- Tiptap is headless and extensible, allowing the CMS to own its block model, workflow and rendering contract.

## Architecture

Public Web / Customer Console / Internal CMS / Regulatory Content / Release Center share the NusaSec design tokens and content contracts. The CMS does not become the business system of record.

## Governance

Content lifecycle: DRAFT → REVIEW → APPROVED → SCHEDULED → PUBLISHED → ARCHIVED.

English is the source locale. Security, legal, finance and regulatory content requires human review before publish.
