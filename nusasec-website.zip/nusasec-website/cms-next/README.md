# NusaSec Content & Experience Platform

Production-oriented frontend foundation for the NusaSec CMS. The target stack is Next.js 16.2.11 + React 19.2.7 + TypeScript, with Tiptap for rich text and Radix primitives for accessible interactive UI. Next.js 16.2.11 is an Active LTS release as of July 2026; React 19.2 is the latest React major/minor line documented by the React team. Radix provides accessible, unstyled primitives designed for custom design systems. See source notes in `docs/CMS_STACK_DECISION_2026-08-17.md`.

## Design goals

- Structured content, not free-form page-builder chaos
- English source locale + 15 additional supported locales
- Approval/versioning/publish workflow
- Preview across locale/theme/device contexts
- Reduced-motion support
- Enterprise information density without dashboard-card overload
- Existing Python/FastAPI backend remains the system of record

## Important implementation note

The sandbox does not have reliable npm registry access, so the dependency graph is declared and audited but not installed/bundled here. The application source is intentionally kept free of direct DOM scripting and uses typed React components for the intended production implementation.
