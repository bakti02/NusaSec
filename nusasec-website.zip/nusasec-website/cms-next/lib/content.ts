export type Locale = "en" | "id" | "zh-Hans" | "zh-Hant" | "ar" | "ja" | "ko" | "de" | "nl" | "ru" | "es" | "hi" | "fr" | "pt-BR" | "it" | "tr";

export type Block =
  | { id: string; type: "hero"; title: string; body: string; cta: string }
  | { id: string; type: "feature-grid"; title: string; items: string[] }
  | { id: string; type: "metrics"; items: { label: string; value: string }[] }
  | { id: string; type: "callout"; tone: "info" | "success" | "warning"; title: string; body: string }
  | { id: string; type: "cta"; title: string; body: string; label: string };

export const page = {
  title: "Cloud Security Platform",
  slug: "/platform",
  status: "DRAFT",
  updatedAt: "2026-08-17T02:40:00+07:00",
  locale: "en" as Locale,
  blocks: [
    { id: "b1", type: "hero", title: "See the security story behind every cloud asset.", body: "Bring cloud, identity, risk, compliance and evidence into one operating view.", cta: "Explore platform" },
    { id: "b2", type: "metrics", items: [{ label: "Control coverage", value: "94%" }, { label: "Critical findings", value: "3" }, { label: "Regulatory impact", value: "7" }] },
    { id: "b3", type: "feature-grid", title: "One context. Every decision.", items: ["Cloud exposure", "Identity paths", "Regulatory mapping", "Evidence readiness"] },
    { id: "b4", type: "callout", tone: "success", title: "Ready for enterprise", body: "Content is localized, reviewed and ready for a staged publish." },
    { id: "b5", type: "cta", title: "Turn security context into action.", body: "Show teams exactly what changed, why it matters and what to do next.", label: "Book a walkthrough" }
  ] satisfies Block[]
};
