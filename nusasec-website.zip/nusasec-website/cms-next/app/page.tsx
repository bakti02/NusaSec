import { CmsWorkspace } from "../components/cms-workspace";

export default function Home() {
  return <CmsWorkspace />;
}
