import "../styles/globals.css";

export const metadata = {
  title: "NusaSec Content & Experience Platform",
  description: "NusaSec CMS prototype",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
