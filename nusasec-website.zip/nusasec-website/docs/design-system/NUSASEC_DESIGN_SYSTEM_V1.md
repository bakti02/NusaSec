# NusaSec Design System v1

## Purpose
A single visual and interaction standard for the NusaSec public site, customer portal, internal operating system, Regulatory Control Tower, notification surfaces, documents, and future product modules.

## Product principles
1. Context first: always show tenant, environment, region, and relevant scope before data.
2. Dense but calm: enterprise information density without visual noise.
3. Evidence before claim: compliance/security metrics should point to evidence and freshness.
4. Role-aware navigation: users only see modules relevant to their permissions.
5. One platform, different workspaces: customer, engineering, security, regulatory, finance, and executive views share the same primitives.
6. No dead-end alerts: notifications always have lifecycle, owner, action, or history.
7. Global by default: locale, timezone, RTL and reduced-motion are first-class capabilities.

## Information architecture
Primary navigation groups:
- Overview
- Security
  - Security
  - Risk
  - Assets / Cloud
  - Evidence
  - Compliance
- Operations
  - Incidents / Reliability
  - Updates
  - Documents
- Business
  - Customers
  - Billing
  - Reports
- Admin
  - Administration

Internal Regulatory Control Tower is a dedicated workspace under Governance/Regulatory; customer users see Compliance Center rather than the internal control tower.

## Global shell
- Left sidebar: 248px desktop reference width.
- Sticky top bar: 72px reference height.
- Global search in the top bar.
- Context selector: organization/tenant, environment, region, and optional time range.
- Notification center at top-right.
- Account / role indicator at top-right.
- Content max-width: 1440px.

## Components
Core components:
- Navigation groups + role-aware menu
- Context selector
- Global search
- KPI card
- Metric card
- Panel / section card
- Severity badge
- Status badge
- Data table
- Filter bar
- Detail drawer
- Modal/dialog
- Banner
- Toast (interaction feedback only)
- Notification center
- Empty state
- Loading state
- Maintenance screen
- Timeline
- Evidence chip
- Approval state
- Export action + export audit state

## Severity semantics
- Critical: immediate action / potential major impact.
- High: urgent remediation.
- Medium: planned action.
- Low: monitor or backlog.
- Info: informational.

Severity is distinct from workflow priority.

## Notification behavior
- Toast: short-lived confirmation of a user action; not used for critical security alerts.
- Banner: current, time-bound attention item. Maintenance banners are visible only inside the maintenance window and disappear after the window ends; dismissing hides the banner while the record remains in Notification Center.
- Notification Center: durable in-app history.
- Modal: reserved for actions that genuinely require blocking confirmation.

## Localization and time
- English (`en`) is the source locale.
- Tier-1 locales: `en`, `id`, `zh-Hans`, `zh-Hant`, `ar`, `ja`, `ko`, `de`, `nl`, `ru`, `es`, `hi`, `fr`, `pt-BR`, `it`, `tr`.
- User-selected locale controls website and notifications.
- Official downloaded documents such as invoices remain canonical English.
- Backend timestamps are UTC; customer-facing times use the recipient/user IANA timezone with DST support.
- Arabic uses RTL layout.

## Theme
- Light is the reference theme for customer-facing product UI.
- Dark is supported for internal/security/engineering workflows.
- Brand color is reserved for actions, focus, links, and product identity.
- Severity colors are semantic and must not be reused as decoration.

## Typography
Recommended system stack:
`Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`

Reference scale:
- Page title: 30px / 36px
- Section heading: 17–20px
- Body: 14–15px
- Metadata: 12–13px
- Eyebrow: 10–11px uppercase with tracking

## Accessibility
- Keyboard navigable controls.
- Visible focus ring.
- Reduced-motion support through `prefers-reduced-motion`.
- Color is never the sole signal.
- RTL tested for Arabic.
- Touch targets should be at least 40px where practical.

## Layout guidance
The NusaSec experience can take inspiration from modern cloud-security consoles such as Wiz in information architecture and density, but must not copy proprietary visual assets, typography, or UI exactly. NusaSec's visual identity should come from its own brand system and the future NusaSec Guardian animation system.

## Export UX
Export is a controlled data-delivery action. Every export exposes:
- dataset / report type
- scope
- requester
- approval state when required
- file format
- creation time
- expiry time
- download audit state

## Design tokens
Canonical CSS tokens live at:
`app/static/design-system/tokens.css`

A reference implementation is available at:
`app/design/index.html`
