# NusaSec Design System v1 — Release Notes

Created as the first unified visual/interaction reference for NusaSec customer and internal surfaces.

Included:
- enterprise console shell inspired by modern cloud-security information architecture;
- context selector and global search;
- role-aware information architecture;
- semantic severity/status tokens;
- notification center, banner, drawer, tables and KPI patterns;
- light/dark theme tokens;
- localization, RTL and timezone rules;
- reduced-motion behavior;
- customer-facing reference dashboard at `app/design/index.html`.

This is a reference implementation, not a claim that every existing screen in the product has already been migrated to every design-system token.
