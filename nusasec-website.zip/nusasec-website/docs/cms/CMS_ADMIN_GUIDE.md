# NusaSec CMS Admin Guide

## Content lifecycle

`DRAFT → REVIEW → APPROVED → PUBLISHED → ARCHIVED`

Authors can create/revise content. Reviewers approve. Publishers publish. Author/self-approval is rejected for the same revision.

## Locales

English (`en`) is the source locale. Supported target locales:
`id`, `zh-Hans`, `zh-Hant`, `ar`, `ja`, `ko`, `de`, `nl`, `ru`, `es`, `hi`, `fr`, `pt-BR`, `it`, `tr`.

Security, legal, finance and regulatory content requires human review before publication. Fallback to English is explicit and auditable.

## Media

Media is registered with checksum and optional storage reference. Upload implementations should use the production object-storage boundary; the CMS database stores metadata and integrity evidence.

## Roles

- `CONTENT_EDITOR`: `cms:read`, `cms:write`
- `CONTENT_REVIEWER`: `cms:read`, `cms:write`, `cms:approve`
- `CONTENT_PUBLISHER`: `cms:read`, `cms:write`, `cms:approve`, `cms:publish`

Platform administrators may manage CMS data through the existing administrative scope boundary.
