# NusaSec CMS Release Notes — 2026-08-17

This release introduces the production-oriented frontend foundation for the NusaSec Content & Experience Platform and a database-backed CMS API.

## Frontend

- Next.js 16.2.11 target
- React 19.2.7 target
- TypeScript target
- Tiptap editor target
- Radix primitives target
- responsive light/dark design tokens
- reduced-motion behavior
- structured block page composition
- localization selector
- command palette pattern
- live preview pattern

## Backend

- CMS content page
- revision model
- translation model
- media metadata model
- publication record
- separate CMS scopes
- reviewer/publisher segregation of duties
- PostgreSQL migration

## Verification

- CMS model tests: 8/8 PASS
- full NusaSec regression with file-backed SQLite: 282/282 PASS
- CMS static/type audit: 19/19 PASS

Dependency installation/build could not be performed from this sandbox because outbound npm registry access is unavailable; the package manifest is intentionally pinned to the researched target versions and the application source is type-audited offline.
