# NusaSec CMS API Contract v1

Base path: `/api/v1/cms`

- `GET /pages`
- `POST /pages`
- `GET /pages/{id}`
- `POST /pages/{id}/revisions`
- `POST /pages/{id}/review`
- `POST /pages/{id}/approve`
- `POST /pages/{id}/publish`
- `POST /pages/{id}/translations`
- `POST /translations/{id}/review`
- `GET /media`
- `POST /media`

Write, approve and publish operations are separately scoped.
