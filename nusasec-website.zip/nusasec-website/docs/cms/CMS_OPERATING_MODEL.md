# NusaSec CMS Operating Model

## Separation of concerns

The CMS is the content/experience layer. The existing Python/FastAPI application remains system-of-record for security, compliance, finance, customer, identity and regulatory data.

## Content model

Pages are structured content: canonical page record → immutable-ish revisions → locale translations → publication evidence. The model intentionally does not store arbitrary executable templates.

## Publishing safety

1. Draft created.
2. Review submitted.
3. Reviewer approves a revision not authored by them.
4. Publisher publishes approved revision.
5. Publication is recorded with revision, locale, timestamp and publisher.

## Public rendering

Only published content is eligible for public rendering. Draft/review/approved states remain internal until publish is committed.
