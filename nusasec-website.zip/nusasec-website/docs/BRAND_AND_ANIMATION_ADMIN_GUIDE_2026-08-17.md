# NusaSec Brand & Animation Admin Guide

## Brand Studio
Manage `logo_primary`, `logo_light`, `logo_dark`, `favicon`, `app_icon`, `og_image`, and `email_logo`. Store production assets in the CMS/media object store and reference them by internal path or HTTPS URL. Public rendering reads only `public_url`; private storage references are not exposed.

## Animation Studio
Animation states are database-backed and editable without code. Each animation has a key, category, contexts, asset type/reference, static fallback, size range, speed, reduced-motion flag, enabled/status, and metadata.

Recommended states:
- maintenance_working — maintenance screen
- loading_initializing — long initial load
- scanning — security/cloud/PQC discovery
- analyzing — risk/regulatory/crypto analysis
- syncing — cloud/evidence/integration sync
- success — completed workflows
- warning — quota/trial expiry/warnings
- critical_alert — critical security findings/incidents
- error_recovery — error/retry/recovery
- update_engine — engine/product release updates
- document_generating — report/document generation
- onboarding_welcome — first login/onboarding
- empty_all_clear — empty/no-alert states
- offline — connectivity loss
- access_denied — permission/session states
- deployment_working — engineering rollout/deployment

Maintenance animation should be the largest default state, centered, calm, and only shown on the active maintenance screen.

All animated states require a reduced-motion fallback.
