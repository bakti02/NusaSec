# NusaSec Product Workspace UX Specification

Every purchased product should answer ten questions without requiring the customer to leave the workspace:

1. What did I buy?
2. What plan do I have?
3. What is included?
4. What is active?
5. What still needs setup?
6. What am I using?
7. What quota remains?
8. What measurable value has been delivered?
9. What should I do next?
10. What is the billing / renewal context?

## Required sections

- Product identity and status
- Plan and renewal state
- Protection / service health
- Included features
- Usage and capacity
- Evidence-backed value metrics
- Active add-ons
- Integrations / connections
- Recent releases / What's New
- Next best actions
- Documentation / support

## Accuracy rule

Never display synthetic ROI or invented readiness scores. If telemetry is missing, display `Not yet measured` or `Unavailable`.
