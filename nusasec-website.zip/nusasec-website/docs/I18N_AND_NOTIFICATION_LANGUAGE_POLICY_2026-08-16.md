# NusaSec Internationalization & Notification Language Policy

## Canonical language
English (`en`) is the source-of-truth locale for product UI, notification semantics, technical terminology, and release content. Other locales are localized presentation layers and must not change event identifiers or audit semantics.

## Tier-1 UI and notification locales
- English (`en`)
- Indonesian (`id`)
- Chinese Simplified (`zh-Hans`)
- Chinese Traditional (`zh-Hant`)
- Arabic (`ar`, RTL)
- Japanese (`ja`)
- Korean (`ko`)
- German (`de`)
- Dutch (`nl`)
- Russian (`ru`)
- Spanish (`es`)
- Hindi (`hi`)
- French (`fr`)
- Portuguese Brazil (`pt-BR`)
- Italian (`it`)
- Turkish (`tr`)

The locale model follows Unicode CLDR conventions: a language and script can be a separate locale, and regional variants can inherit from a neutral base language.

## User behavior
1. The website exposes a language selector on public site, login, customer console, and internal console.
2. A signed-in user's preference is persisted on `UserAccount.preferred_locale`.
3. The current UI direction is automatically changed to RTL for Arabic.
4. Notification rendering reads the recipient's preferred locale before rendering the notification.
5. The notification event, severity, sender identity, template key, and audit trail remain language-neutral.
6. Unknown/unsupported locale values normalize back to English.
7. Anonymous visitors use English by default; the public language selector can be used without authentication.

## Notifications
Notification templates are versioned and localized. The canonical template/event key stays English and machine-stable; only title/body presentation changes by locale.

The first production seed templates cover critical vulnerability, product release, engine update, maintenance, and invoice-due notifications. Other notification types must use the English source template until a reviewed translation is published.

## Documents
Customer-downloaded invoices, receipts, credit notes, statements, payment confirmations, security reports, evidence packages, CBOM/PQC reports, compliance reports, proposals, SOWs, contracts, and other generated artifacts remain **English (`en`) by policy** for the current release. User UI language must never silently change the document artifact language.

Generated document metadata records `document_locale = en` as evidence of this invariant.

## Translation governance
- English is always the source catalog.
- New strings require an English source key before translation.
- Security, finance, legal, and compliance wording requires human review before being marked production-translated.
- Missing translations must fall back to English; they must never produce blank text or a machine-translated security/legal claim without review.
