(function(){
  const state={locale:'en', catalog:{}};
  function esc(v){const d=document.createElement('div');d.textContent=v;return d.innerHTML}
  function setDirection(dir){document.documentElement.dir=dir||'ltr'}
  function setLocale(locale){document.documentElement.lang=locale||'en';}
  function apply(){
    document.querySelectorAll('[data-i18n]').forEach(el=>{const k=el.getAttribute('data-i18n');if(state.catalog[k])el.textContent=state.catalog[k]});
    document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>{const k=el.getAttribute('data-i18n-placeholder');if(state.catalog[k])el.placeholder=state.catalog[k]});
    const select=document.querySelector('[data-language-select]'); if(select) select.value=state.locale;
  }
  async function api(path,opt={}){const r=await fetch(path,{credentials:'include',...opt,headers:{'Content-Type':'application/json',...(opt.headers||{})}});const t=await r.text();let d={};try{d=JSON.parse(t)}catch{};if(!r.ok)throw new Error(d.detail||`HTTP ${r.status}`);return d}
  async function load(){
    const d=await api('/api/v1/i18n/preferences').catch(()=>({locale:localStorage.getItem('nusasec_locale')||'en',direction:'ltr',catalog:{}}));
    state.locale=d.locale||localStorage.getItem('nusasec_locale')||'en';state.catalog=d.catalog||{};localStorage.setItem('nusasec_locale',state.locale);setDirection(d.direction);setLocale(state.locale);apply();
    const sel=document.querySelector('[data-language-select]');
    if(sel){
      const ls=await api('/api/v1/i18n/locales');
      sel.innerHTML=ls.items.map(x=>`<option value="${esc(x.code)}">${esc(x.native)}</option>`).join('');
      sel.value=state.locale;
      sel.onchange=async()=>{const v=sel.value;const out=await api('/api/v1/i18n/preferences',{method:'PUT',body:JSON.stringify({locale:v})});state.locale=out.locale;state.catalog=out.catalog||{};localStorage.setItem('nusasec_locale',v);setDirection(out.direction);setLocale(v);apply();window.dispatchEvent(new CustomEvent('nusasec:locale-changed',{detail:{locale:v}}));location.reload();};
    }
  }
  window.NusaSecI18n={load,get locale(){return state.locale}};
  document.addEventListener('DOMContentLoaded',()=>load());
})();
